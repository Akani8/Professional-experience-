﻿using System;
using System.Security.Cryptography;
using System.Text;

public class Secracy
{
	public string HashPassword(string text)
    {
        using(SHA1 sha1Hash = SHA1.Create())
        {
            byte[] sourceBytes = Encoding.UTF8.GetBytes(text);

            byte[] hashBytes = sha1Hash.ComputeHash(sourceBytes);

            string hashedText = BitConverter.ToString(hashBytes).Replace("-", String.Empty);

            return hashedText;
        }
    }
}
