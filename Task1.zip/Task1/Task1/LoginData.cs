﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class LoginData
    {
        private string username, password;

        public LoginData(string Username, string Password)
        {
            this.username = Username;
            this.password = Password;
        }

        public string getUsername()
        {
            return username;

        }

        public string getPassword()
        {
            return password;
        }

    }
}
