﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int TotalSTudySessionHours;
        int RemaingHours;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TxtCode_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnSaveData_Click(object sender, RoutedEventArgs e)
        {
            string module_code = txtCode.Text;
            string module_name = txtName.Text;
            string study_date = Study_Date.Text;
            string start_date = start_DatePicker.Text;
            int numberOfCredits = int.Parse(txtCredit.Text);
            int classHoursPerWeek = int.Parse(txtClassHours.Text);
            int semesterWeeks = int.Parse(txtSemWeeks.Text);
            int studyHours = int.Parse(txtNumModules.Text);
            Data data = new Data(module_code, module_name, start_date, study_date, numberOfCredits, classHoursPerWeek, semesterWeeks, studyHours);
            TotalSTudySessionHours = data.calculateSelfStudy();

            List<string> ModuleName = new List<string>();
            ModuleName.Add("Code: " + module_code + "Name: " + module_name + "Start Date: " + start_date + numberOfCredits + "Credits" + numberOfCredits + "Class Hours:" + classHoursPerWeek + "Semester Weeks: " + semesterWeeks + "Study Session Hours: " + TotalSTudySessionHours + "Study Hours Date: " + study_date);

            List<int> sumOfHours = new List<int>
               (new int[] { studyHours });

            RemaingHours = sumOfHours.Sum();

            foreach (var item in ModuleName)
            {
                Output.Items.Add(item);
            }
        }

        private void BtnCalc_Click(object sender, RoutedEventArgs e)
        {
            int finalCalculation = TotalSTudySessionHours - RemaingHours;
            lblCalc.Content = finalCalculation.ToString();
        }

        private void BtnsaveDatabase_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Open();
            string module_code = txtCode.Text;
            string module_name = txtName.Text;
            string study_date = Study_Date.Text;
            string start_date = start_DatePicker.Text;
            int numberOfCredits = int.Parse(txtCredit.Text);
            int classHoursPerWeek = int.Parse(txtClassHours.Text);
            int semesterWeeks = int.Parse(txtSemWeeks.Text);
            int studyHours = int.Parse(txtNumModules.Text);
            Data data = new Data(module_code, module_name, start_date, study_date, numberOfCredits, classHoursPerWeek, semesterWeeks, studyHours);
            SqlCommand cmd = new SqlCommand("insert into StudyDetails values(@module_code,@module_name,@start_date,@study_date,@num_of_credits,@classHoursPerWeek,@semesterWeeks,@remainingHours)", cn);
            cmd.Parameters.AddWithValue("module_code", data.getCode());
            cmd.Parameters.AddWithValue("module_name", data.getName());
            cmd.Parameters.AddWithValue("start_date", data.getStart_Date());
            cmd.Parameters.AddWithValue("study_date", data.getStudy_Date());
            cmd.Parameters.AddWithValue("num_of_credits", data.getNumberOfCredits());
            cmd.Parameters.AddWithValue("classHoursPerWeek", data.getClassHoursPerWeek());
            cmd.Parameters.AddWithValue("semesterWeeks", data.getSemesterWeeks());
            cmd.Parameters.AddWithValue("remainingHours", data.getRemainingHours());
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Has Been Saved Successfully.", "Done", MessageBoxButton.OK, MessageBoxImage.Information);

            cn.Close();

        }
    }
}
