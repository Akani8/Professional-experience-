﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Task1
{
    /// <summary>
    /// Interaction logic for UserLogin.xaml
    /// </summary>
    public partial class UserLogin : Window
    {
        public UserLogin()
        {
            InitializeComponent();
        }

        private void Btnlogin_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Open();
            string username = txtusername.Text;
            string password = txtpassword.Text;
            LoginData data = new LoginData(username, password);
            if (password != string.Empty || username != string.Empty)
            {

                SqlCommand cmd = new SqlCommand("select * from UserDetails where username='" + data.getUsername() + "' and password='" + data.getPassword() + "'", cn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dr.Close();
                    this.Hide();
                    MainWindow home = new MainWindow();
                    home.ShowDialog();
                }
                else
                {
                    dr.Close();
                    MessageBox.Show("Username or Password does not exist!!! ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
            else
            {
                MessageBox.Show("A field was left empty", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            Connection();
        }
        public static void Connection()
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Close();

        }

        private void Btnregister_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            UserRegisteration reg = new UserRegisteration();
            reg.ShowDialog();
        }
    }
}
