﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Task1
{
    /// <summary>
    /// Interaction logic for UserRegisteration.xaml
    /// </summary>
    public partial class UserRegisteration : Window
    {
        public UserRegisteration()
        {
            InitializeComponent();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Open();
            
            if (txtconfirmpass.Text != string.Empty || txtpassword.Text != string.Empty || txtusername.Text != string.Empty)
            {
                string username = txtusername.Text;
                string password = txtpassword.Text;
                LoginData data = new LoginData(username, password);
                Secracy hashpass = new Secracy();
                
                if (password == txtconfirmpass.Text)
                {
                    SqlCommand cmd = new SqlCommand("select * from UserDetails where username='" + data.getUsername() + "'", cn);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        MessageBox.Show("This User name exists please select another ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        dr.Close();
                        cmd = new SqlCommand("insert into UserDetails values(@username,@password)", cn);
                        cmd.Parameters.AddWithValue("username", data.getUsername());
                        cmd.Parameters.AddWithValue("password", data.getPassword());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Your Account has been created successfully. Please login .", "Done", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.Hide();
                        UserLogin login = new UserLogin();
                        login.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Passwords do not match ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("A feild was left empty!!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            Connection();
        }
        public static void Connection()
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Close();

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            UserLogin login = new UserLogin();
            login.ShowDialog();
        }
    }
   
}
