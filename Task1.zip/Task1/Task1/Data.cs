﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Data
    {
        private string code, name, start_date, study_date;
        private int numberOfCredits, classHoursPerWeek, semesterWeeks, remainingHours;

        public Data(string Code, string Name, string Start_date, string Study_date, int NumberOfCredits, int ClassHoursPerWeek, int SemesterWeeks, int RemainingHours)
        {
            this.code = Code;
            this.name = Name;
            this.start_date = Start_date;
            this.study_date = Study_date;
            this.numberOfCredits = NumberOfCredits;
            this.classHoursPerWeek = ClassHoursPerWeek;
            this.semesterWeeks = SemesterWeeks;
            this.remainingHours = RemainingHours;
        }

        public string getCode()
        {
            return code;
        }
        public string getName()
        {
            return name;
        }
        public string getStart_Date()
        {
            return start_date;
        }
        public string getStudy_Date()
        {
            return study_date;
        }
        public int getNumberOfCredits()
        {
            return numberOfCredits;
        }
        public int getClassHoursPerWeek()
        {
            return classHoursPerWeek;
        }

        public int getSemesterWeeks()
        {
            return semesterWeeks;
        }

        public int getRemainingHours()
        {
            return remainingHours;
        }

        public int calculateSelfStudy()
        {
            int selfStudy = 0;
            selfStudy = (numberOfCredits * 10 / semesterWeeks) - classHoursPerWeek;
            return selfStudy;

        }

      
    }
}
