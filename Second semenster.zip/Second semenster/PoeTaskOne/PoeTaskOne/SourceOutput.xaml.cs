﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PoeTaskOne
{
    /// <summary>
    /// Interaction logic for SourceOutput.xaml
    /// </summary>
    public partial class SourceOutput : Window
    {
        public SourceOutput()
        {
            myLab.capturer xs = new myLab.capturer();
            InitializeComponent();
          //  myLab.capturer.Output.Text = myLab.capturer.Output();
        }

        private void Btn_1_Display_Click(object sender, RoutedEventArgs e)
        {
            myLab.capturer xs = new myLab.capturer();
         //   Window window = new hoursRem();
            this.Close();

               
            

        }
    }
}
