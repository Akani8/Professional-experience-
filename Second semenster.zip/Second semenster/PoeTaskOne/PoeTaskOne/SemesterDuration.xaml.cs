﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PoeTaskOne
{
    /// <summary>
    /// Interaction logic for SemesterDuration.xaml
    /// </summary>
    public partial class SemesterDuration : Window
    {
        public SemesterDuration()
        {
            InitializeComponent();
        }

        private void Btn_1_Proceed_Click(object sender, RoutedEventArgs e)
        {
            SourceOutput display = new SourceOutput();

            try
            {
                myLab.capturer.noOfWeeks = Convert.ToInt32(txtBx_1_Weeks.Text);
                myLab.capturer.startOfSem = dtp_date.SelectedDate.Value;
                myLab.capturer.endOfSem = myLab.capturer.startOfSem.AddDays(7 * myLab.capturer.noOfWeeks);
            }

            catch (Exception warning)
            {
                MessageBox.Show(warning.Message);
            }
            display.Show();
            this.Hide();
        }
    }
}
