﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PoeTaskOne
{
    /// <summary>
    /// Interaction logic for Modules.xaml
    /// </summary>
    public partial class Modules : Window
        
    {
        int counter;
        public Modules()
        {
            InitializeComponent();
        }

        private void Btn_1_Save_Click(object sender, RoutedEventArgs e)
        {
            Array.Resize(ref myLab.capturer.moduleCode, myLab.capturer.moduleCode.Length +1);
            Array.Resize(ref myLab.capturer.moduleName, myLab.capturer.moduleName.Length + 1);
            Array.Resize(ref myLab.capturer.moduleCredit, myLab.capturer.moduleCredit.Length + 1);
            Array.Resize(ref myLab.capturer.classHours, myLab.capturer.classHours.Length+1);

            try
            {
                myLab.capturer.moduleCode[counter] = Convert.ToInt32(txtBx_2_Code.Text);
                myLab.capturer.moduleName[counter] = txtBx_1_Name.Text;
                myLab.capturer.moduleCredit[counter] = Convert.ToInt32(txtBx_4_Credit.Text);
                myLab.capturer.classHours[counter]= Convert.ToInt32(txtBx_3_Hours.Text);
                    counter ++;
                MessageBox.Show("Data has been Captured");
                txtBx_2_Code.Clear();
                txtBx_1_Name.Clear();
                txtBx_4_Credit.Clear();
                txtBx_3_Hours.Clear();

            }

            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }



        }

        private void Btn_2_Next_Click(object sender, RoutedEventArgs e)
        {
            SemesterDuration nxtbt = new SemesterDuration();
            nxtbt.Show();
            this.Hide();
        }
    }
}
