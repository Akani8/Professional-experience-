﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myLab
{
    class capturer
    {
        //capturer[] mysets = 
       public static int[] moduleCode = new int[0];
        public static string[] moduleName = new string[0];
        public static int[] moduleCredit = new int[0];
        public static int[] classHours = new int[0];
        public static int[] HoursToStudy = new int[0];
        public static int[] hoursRemaining = new int[0];
        public static double[] studyHours = new double[0];

        public static int noOfWeeks;
        public static DateTime startOfSem;
        public static DateTime endOfSem;


        public static string Output()
        {
            endOfSem = startOfSem.AddDays(7 * noOfWeeks);
            for (int i = 0; i < moduleCode.Length; i++)
            {
                studyHours[i] = (moduleCredit[i] * 10) / (noOfWeeks) - classHours[i];
            }
            string viewPart = "START DATE" + startOfSem.Date + "\n End Date" + endOfSem.Date +
                "\t Module Name" + "\t Module code" + "\t class per hour" +
                "\t hours of self study" + "\n";
            for (int i = 0; i < moduleCode.Length; i++)
            {
                viewPart = viewPart + moduleName[i] + "\t" +
                    moduleCode[i] + "\t" +
                    moduleCredit[i] + "\t" +
                    classHours[i] + "\t" +
                    studyHours[i] + "\n";
            }
            return viewPart;
        }
            public static string hoursRem()
            {
                for (int i = 0; i < moduleCode.Length; i++)
            {
                hoursRemaining[i] = classHours[i] - HoursToStudy[i];

            }
            string viewPart = "Module name" + "\t Module Code" + "\t STUDY HOURS REMAINING" + "\n";
            for (int i = 0; i < moduleCode.Length; i++)
            {
                viewPart = viewPart + "\n" +
                    moduleName[i] + "\t" + "\t" + "\t" + "\n" +
                    moduleCode[i] + "\t" + "\t" + "\t" + "\n" +
                    hoursRemaining[i];
            }
            return viewPart;
            }

                
    }

    
}
