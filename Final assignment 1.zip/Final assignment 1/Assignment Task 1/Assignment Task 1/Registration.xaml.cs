﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Assignment_Task_1
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\Final assignment 1\Assignment Task 1\Assignment Task 1\StudentDB.mdf;Integrated Security=True");
            cn.Open();
            //
            if (txtsurname.Text != string.Empty || txtpassword.Text != string.Empty || txtstudentNum.Text != string.Empty || txtstudentNum.Text != string.Empty)
            {
                string studentNum = txtstudentNum.Text; string name = txtname.Text; string surname = txtsurname.Text; string password = txtpassword.Text;
                Student students = new Student(studentNum, name, surname, password);


                SqlCommand cmd = new SqlCommand("select * from LoginDetails where student_number='" + students.getStudentNum() + "'", cn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dr.Close();
                    MessageBox.Show("A student has this Student Number!!!");
                }

                else
                {
                    dr.Close();
                    cmd = new SqlCommand("insert into LoginDetails values(@student_number,@name,@surname,@password)", cn);
                    cmd.Parameters.AddWithValue("student_number", students.getStudentNum());
                    cmd.Parameters.AddWithValue("name", students.getName());
                    cmd.Parameters.AddWithValue("surname", students.getSurname());
                    cmd.Parameters.AddWithValue("password", students.getPassword());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Account Successfully created, you may kindly login.");
                    this.Hide();
                    login log = new login();
                    log.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Empty textbox!!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            cn.Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            login log = new login();
            log.ShowDialog();
        }
    }
}
