﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Task_1
{
    class Student
    {
        private string studentNum, name, 
                       surname, password;

        public Student(string StudentNum, string Name, string Surname, string Password)
        {
            this.studentNum = StudentNum;
            this.name = Name;
            this.surname = Surname;
            this.password = Password;
        }

        public string getStudentNum()
        {
            return studentNum;
        }
        public string getName()
        {
            return name;
        }
        public string getSurname()
        {
            return surname;
        }
        public string getPassword()
        {
            return password;
        }
    }
}
