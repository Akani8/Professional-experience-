﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment_Task_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int self_study = 0;
        int CounterStudyHours = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnUpload_Click(object sender, RoutedEventArgs e)
        {
            string module_code = Module_Code.Text;
            string module_name = Module_name.Text;
            string semester_start_date = StartDateCalender.ToString();
            string study_hours_date = studyDateCalender.ToString();
            int module_Credits = int.Parse(Module_credits.Text);
            int weeklyClassHours = int.Parse(Weekly_Class_Hours.Text);
            int semesterWeeks = int.Parse(Semester_Weeks.Text);
            int moduleStudyHours = int.Parse(module_study_hours.Text);

            DataLibrary lib = new DataLibrary(module_code, module_name, semester_start_date, study_hours_date, module_Credits, weeklyClassHours, semesterWeeks, moduleStudyHours);

            List<int> counter = new List<int>();
            counter.Add(moduleStudyHours);
            CounterStudyHours = counter.Sum();

            self_study = lib.calculationForSelfStudy();

            List<string> Data_Collection = new List<string>();
            Data_Collection.Add("Module Code : "+module_code);
            Data_Collection.Add("Module Name : " +module_name);
            Data_Collection.Add("Semester Start Date : "+ semester_start_date);
            Data_Collection.Add("Request For Study Hours Of Module : "+ study_hours_date);
            Data_Collection.Add("Module Credits : "+module_Credits.ToString());
            Data_Collection.Add("Weekly Class Hours : "+weeklyClassHours.ToString());
            Data_Collection.Add("Total Semester Weeks : "+semesterWeeks.ToString());
            Data_Collection.Add("Module Study Hours : " +moduleStudyHours.ToString());
            Data_Collection.Add("Self Study time is: " + self_study.ToString());

            foreach (var item in Data_Collection)
            {
                lstView.Items.Add(item);
            }
            

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int total = self_study - CounterStudyHours;
            MessageBox.Show("Remaining self study for this semester is: " + total + " Use your time wisely to study!!!");
        }

        private void Btndatabase_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\thato task 1\Task1\Task1\UserData.mdf;Integrated Security=True");
            cn.Open();
            string module_code = Module_Code.Text;string module_name = Module_name.Text;string semester_start_date = StartDateCalender.ToString();string study_hours_date = studyDateCalender.ToString();
            int module_Credits = int.Parse(Module_credits.Text);int weeklyClassHours = int.Parse(Weekly_Class_Hours.Text);int semesterWeeks = int.Parse(Semester_Weeks.Text);int moduleStudyHours = int.Parse(module_study_hours.Text);
            DataLibrary lib = new DataLibrary(module_code, module_name, semester_start_date, study_hours_date, module_Credits, weeklyClassHours, semesterWeeks, moduleStudyHours);
            SqlCommand cmd = new SqlCommand("insert into StudyDetails values(@module_code,@module_name,@semesterWeeks,@remainingHours,@classHoursPerWeek,@numberOfCredits,@study_date,@start_date)", cn);
            cmd.Parameters.AddWithValue("module_code", lib.getModuleCode());
            cmd.Parameters.AddWithValue("module_name", lib.getModuleName());
            cmd.Parameters.AddWithValue("semesterWeeks", lib.getSemesterWeeks());
            cmd.Parameters.AddWithValue("remainingHours", lib.getRemainingHours());
            cmd.Parameters.AddWithValue("classHoursPerWeek", lib.getClassHoursPerWeek());
            cmd.Parameters.AddWithValue("numberOfCredits", lib.getCredits());
            cmd.Parameters.AddWithValue("study_date", lib.getStudyHoursDate());
            cmd.Parameters.AddWithValue("start_date", lib.getSemesterStartDate());
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Has Been Saved Successfully.", "Done", MessageBoxButton.OK, MessageBoxImage.Information);

            cn.Close();
        }
    }
}
