﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_Task_1
{
    class DataLibrary
    {
        //variables that will be used 
        private string moduleCode, moduleName, semesterStartDate, studyHoursDate;

        private int credits, classHoursPerWeek, semesterWeeks, remainingHours;

        //constructor
        public DataLibrary(string ModuleCode, string ModuleName, string SemesterStartDate, string StudyHoursDate,  int Credits, int ClassHoursPerWeek, int SemesterWeeks, int RemainingHours)
        {
            this.moduleCode = ModuleCode;
            this.moduleName = ModuleName;
            this.semesterStartDate = SemesterStartDate;
            this.studyHoursDate = StudyHoursDate;
            this.credits = Credits;
            this.classHoursPerWeek = ClassHoursPerWeek;
            this.semesterWeeks = SemesterWeeks;
            this.remainingHours = RemainingHours;
        }

        public string getModuleCode()
        {
            return moduleCode;
        }
        public string getModuleName()
        {
            return moduleName;
        }
        public string getSemesterStartDate()
        {
            return semesterStartDate;
        }
        public string getStudyHoursDate()
        {
            return studyHoursDate;
        }
        public int getCredits()
        {
            return credits;
        }
        public int getClassHoursPerWeek()
        {
            return classHoursPerWeek;
        }

        public int getSemesterWeeks()
        {
            return semesterWeeks;
        }

        public int getRemainingHours()
        {
            return remainingHours;
        }
        public int calculationForSelfStudy()
        {
            int Study_Total = 0;
            int preCal  = (credits * 10 / semesterWeeks);
            Study_Total = preCal - classHoursPerWeek;
            return Study_Total;
        }
    }
}
