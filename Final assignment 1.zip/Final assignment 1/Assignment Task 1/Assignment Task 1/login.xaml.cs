﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Assignment_Task_1
{
    /// <summary>
    /// Interaction logic for login.xaml
    /// </summary>
    public partial class login : Window
    {
        public login()
        {
            InitializeComponent();
        }

        private void Btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\General\Desktop\Final assignment 1\Assignment Task 1\Assignment Task 1\StudentDB.mdf;Integrated Security=True");
            cn.Open();
            string studentNum = txtstudentNum.Text; string password = txtpassword.Text; string name = ""; string surname = "";
            Student students = new Student(studentNum, name, surname, password);
            if (password != string.Empty || studentNum != string.Empty)
            {

                SqlCommand cmd = new SqlCommand("select * from LoginDetails where student_number='" + students.getStudentNum() + "' and password='" + students.getPassword() + "'", cn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    dr.Close();
                    this.Hide();
                    MainWindow portal = new MainWindow();
                    portal.ShowDialog();
                }
                else
                {
                    dr.Close();
                    MessageBox.Show("Credentials do not exist, please try again!!! ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            }
            else
            {
                MessageBox.Show("Empty textbox", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            cn.Close();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Registration register = new Registration();
            register.ShowDialog();
        }
    }
}
